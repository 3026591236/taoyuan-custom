import{c as e}from"./createLucideIcon-DZZfogfg.js";const a=e("egg",[["path",{d:"M12 2C8 2 4 8 4 14a8 8 0 0 0 16 0c0-6-4-12-8-12",key:"1le142"}]]);export{a as E};
