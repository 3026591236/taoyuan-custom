System.register(["./createLucideIcon-legacy-D0rmoCmF.js"],function(e,t){"use strict";var a;return{setters:[function(e){a=e.c}],execute:function(){
/**
       * @license lucide-vue-next v0.563.0 - ISC
       *
       * This source code is licensed under the ISC license.
       * See the LICENSE file in the root directory of this source tree.
       */
e("P",a("pickaxe",[["path",{d:"m14 13-8.381 8.38a1 1 0 0 1-3.001-3L11 9.999",key:"1lw9ds"}],["path",{d:"M15.973 4.027A13 13 0 0 0 5.902 2.373c-1.398.342-1.092 2.158.277 2.601a19.9 19.9 0 0 1 5.822 3.024",key:"ffj4ej"}],["path",{d:"M16.001 11.999a19.9 19.9 0 0 1 3.024 5.824c.444 1.369 2.26 1.676 2.603.278A13 13 0 0 0 20 8.069",key:"8tj4zw"}],["path",{d:"M18.352 3.352a1.205 1.205 0 0 0-1.704 0l-5.296 5.296a1.205 1.205 0 0 0 0 1.704l2.296 2.296a1.205 1.205 0 0 0 1.704 0l5.296-5.296a1.205 1.205 0 0 0 0-1.704z",key:"hh6h97"}]]))}}});
