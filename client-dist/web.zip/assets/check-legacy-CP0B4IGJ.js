System.register(["./createLucideIcon-legacy-D0rmoCmF.js"],function(e,c){"use strict";var t;return{setters:[function(e){t=e.c}],execute:function(){
/**
			 * @license lucide-vue-next v0.563.0 - ISC
			 *
			 * This source code is licensed under the ISC license.
			 * See the LICENSE file in the root directory of this source tree.
			 */
e("C",t("check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]))}}});
