System.register(["./createLucideIcon-legacy-D0rmoCmF.js"],function(e,t){"use strict";var c;return{setters:[function(e){c=e.c}],execute:function(){
/**
       * @license lucide-vue-next v0.563.0 - ISC
       *
       * This source code is licensed under the ISC license.
       * See the LICENSE file in the root directory of this source tree.
       */
e("Z",c("zap",[["path",{d:"M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z",key:"1xq2db"}]]))}}});
